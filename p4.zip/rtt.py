rtt = 0.25
